
#ifndef _IMAGEDATA_H_
#define _IMAGEDATA_H_

extern const unsigned char gImage_2in9[];
extern const unsigned char gImage_2in91[];

#endif
/* FILE END */


