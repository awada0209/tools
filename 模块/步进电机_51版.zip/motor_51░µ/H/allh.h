#ifndef	__ALLH_H
#define	__ALLH_H
#include "reg52.h"
#include "motor.h"
#include "timer.h"
#include "key.h"

#endif

