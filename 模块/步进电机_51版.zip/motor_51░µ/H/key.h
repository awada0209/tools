#ifndef	__KEY_H
#define	__KEY_H

extern unsigned char xdata Key;

unsigned char Key_scan(unsigned char Long_Flag);

#endif

