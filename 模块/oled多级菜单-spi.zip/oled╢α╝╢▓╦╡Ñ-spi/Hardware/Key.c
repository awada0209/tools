#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);//使能GPIOB和AFIO时钟，AFIO用于PB3、PB4重定义功能
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);//关闭PA15、PB3的JTAG功能，重定义其功能
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_7 | GPIO_Pin_6 | GPIO_Pin_5 | GPIO_Pin_4 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

uint8_t Key_GetNum(void)
{
	static uint8_t keyflag=0;
	uint8_t KeyNum = 0;
	
	if(keyflag==0)
	{
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 0)
		{
			Delay_ms(20);
			KeyNum = 1;
			keyflag=1;
		}
		/*if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == 0)
		{
			Delay_ms(20);
			KeyNum = 2;
			keyflag=1;
		}*/
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0)
		{
			Delay_ms(20);
			KeyNum = 3;
			keyflag=1;
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 0)
		{
			Delay_ms(20);
			KeyNum = 4;
			keyflag=1;
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 0)
		{
			Delay_ms(20);
			KeyNum = 5;
			keyflag=1;
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3) == 0)
		{
			Delay_ms(20);
			KeyNum = 6;
			keyflag=1;
		}
	}
	else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 1 &&
					GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == 1 &&
					GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 1 &&
					GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 1 &&
					GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 1 &&
					GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3) == 1 )
				keyflag=0;
	
	return KeyNum;
}

/*uint8_t KeyNum;
void key(void)
{
	KeyNum = Key_GetNum();
	if (KeyNum == 4)
	{
		
	}
}*/
