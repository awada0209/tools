#ifndef __KEY_H
#define __KEY_H

#define KeyL			1
#define KeyR			2
#define Key_right	3
#define Key_down	4
#define Key_left	5
#define Key_up		6

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
