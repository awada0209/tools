#ifndef __OLED_FONT_H
#define __OLED_FONT_H

extern const unsigned char oled_asc2_1206[95][12];
extern const unsigned char oled_asc2_1608[][16];
extern const unsigned char character16[];
extern const unsigned char oled_CH_1616[][16];
extern const unsigned char character12[];
extern const unsigned char oled_CH_1212[][12];
extern const unsigned char oled_CH1[][12];
extern const unsigned char lsm[][16];
extern const unsigned char mihoyo[1024];
extern const unsigned char yuanshen[1024];

#endif
