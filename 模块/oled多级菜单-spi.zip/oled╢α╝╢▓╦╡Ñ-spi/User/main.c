#include "stm32f10x.h"                  // Device header
#include "Key.h"
#include "Delay.h"
#include "OLED.h"
#include "menu.h"

u8 tf;
int main(void)
{
	Key_Init();
	OLED_Init();
	menu_init();
	while (1)
	{
		menu();
		if(tf>50)
		{
			fps=fp*2;
			fp=0;
			tf=0;
		}
	}
}

