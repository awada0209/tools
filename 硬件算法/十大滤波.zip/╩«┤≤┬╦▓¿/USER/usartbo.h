#ifndef __USARTBO_H
#define __USARTBO_H	
#include "sys.h"


//void print_host(u16 val);
void print_host(u16 val,u16 a);
#endif 



